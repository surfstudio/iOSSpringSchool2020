import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

// Простейшая операция

let operation1 = {
    print("Operation 1 started")
    print("Operation 1 finished")
}

let queue = OperationQueue()
queue.addOperation(operation1)

// Полноценная операция
// BlockOperation

//var result: String?
//
//let concatenationOperaiton = BlockOperation {
//    result = "👒" + "⛑"
//    print("did change")
////    print("------👒" + "⛑")
//    sleep(2)
//}

//concatenationOperaiton.qualityOfService = .userInitiated
//
//duration {
//    concatenationOperaiton.start()
//}
//
//print(result)
//result

// Создание очередей операций

//let printerQueue = OperationQueue()
//
//printerQueue.maxConcurrentOperationCount = 1
//
//duration {
//    printerQueue.addOperation {  print("Каждый 🍎"); sleep(2) }
//    printerQueue.addOperation {  print("Охотник 🍊"); sleep(2) }
//    printerQueue.addOperation {  print("Желает 🍋"); sleep(2) }
//    printerQueue.addOperation {  print("Знать 🍏"); sleep(2) }
//    printerQueue.addOperation {  print("Где 💎"); sleep(2) }
//    printerQueue.addOperation {  print("Сидит 🚙"); sleep(2) }
//    printerQueue.addOperation {  print("Фазан 🍆"); sleep(2) }
//
//    printerQueue.addOperation(concatenationOperaiton)
//}
//
//duration {
//    printerQueue.waitUntilAllOperationsAreFinished()
//}

