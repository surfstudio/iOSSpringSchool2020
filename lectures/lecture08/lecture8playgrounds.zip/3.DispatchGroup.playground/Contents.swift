import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let view = UIView(frame: CGRect(x: 0, y: 0, width: 300, height: 600))
let image1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
let image2 = UIImageView(frame: CGRect(x: 0, y: 300, width: 300, height: 300))

image1.backgroundColor = .cyan
image1.contentMode = .scaleAspectFill
image2.backgroundColor = .red
image2.contentMode = .scaleAspectFill
image1.isHidden = true
image2.isHidden = true
view.addSubview(image1)
view.addSubview(image2)
PlaygroundPage.current.liveView = view

func fetchImage(with imagePath: String, completion: @escaping (UIImage?) -> Void) {
    let imageURL = URL(string: imagePath)!
    let queue = DispatchQueue.global(qos: .utility)
    queue.async {
        if let data = try? Data(contentsOf: imageURL) {
            DispatchQueue.main.async {
                completion(UIImage(data: data))
            }
        }
    }
}

//fetchImage(with: "https://litbro.ru/wp-content/uploads/2019/12/Velsh-korgi-7-640x420.jpg", completion: { image in
//    image1.image = image
//})
//fetchImage(with: "https://prohvost.club/wp-content/uploads/2019/07/post_5d1b592c2c5ee-600x399.jpg", completion: { image in
//    image2.image = image
//})


let group = DispatchGroup()

group.enter()

fetchImage(with: "https://litbro.ru/wp-content/uploads/2019/12/Velsh-korgi-7-640x420.jpg", completion: { image in
    image1.image = image
    // Выходим из группы
    group.leave()
})

group.enter()

fetchImage(with: "https://prohvost.club/wp-content/uploads/2019/07/post_5d1b592c2c5ee-600x399.jpg", completion: { image in
    image2.image = image
    group.leave()
})

group.notify(queue: .main) {
    image1.isHidden = false
    image2.isHidden = false
}
