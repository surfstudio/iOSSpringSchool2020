import UIKit

let deadlockQueue = DispatchQueue(label: "com.surfstudio.deadlockQueue")

print("1")
deadlockQueue.async {
    print("2")
    deadlockQueue.sync {
        print("3")
    }
    print("4")
}
print("5")
