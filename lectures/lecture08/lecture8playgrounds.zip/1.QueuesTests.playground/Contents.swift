import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true


// Глобальная последовательная очередь

let mainQueue = DispatchQueue.main

// Глобальные concurrent очереди

let userInteractiveQueue = DispatchQueue.global(qos: .userInteractive)
let userQueue = DispatchQueue.global(qos: .userInitiated)
let utilityQueue = DispatchQueue.global(qos: .utility)
let backgroundQueue = DispatchQueue.global(qos: .background)


// Глобальная concurent .default очередь

let defaultQueue = DispatchQueue.global()

func task(_ symbol: String) {
    for i in 1...10 {
        print("\(symbol) \(i) приоритет = \(qos_class_self().rawValue)")
    }
}

// Пример синхронности и асинхронности

print("---------------------------------")
print("Синхронность")
print("Q1 - .userInitiated")
print("---------------------------------")
userQueue.sync { task("🍡") }
task("🐠")
sleep(3)

print("---------------------------------")
print("Асинхронность")
print("Q1 - .userInitiated")
print("---------------------------------")
userQueue.async { task("🐢") }
task("🦕")

// Private Serial Queue

//let mySerialQueue = DispatchQueue(label: "com.surfstudio.serialQueue")
//
//print("---------------------------------")
//print("Синхронность")
//print("Q1 - .no")
//print("---------------------------------")
//mySerialQueue.sync { task("🍡") }
//task("🐠")
//sleep(3)
//
//print("---------------------------------")
//print("Асинхронность")
//print("Q1 - .no")
//print("---------------------------------")
//mySerialQueue.async { task("🐢") }
//task("🦕")

// Приоритеты QoS последовательных очередей

let serialPriorityQueue = DispatchQueue(label: "com.surfstudio.serialPriorityQueue", qos: .userInitiated)
//
//print("---------------------------------")
//print("Private .serial Q1 - .userInitiated")
//print("---------------------------------")
//
//serialPriorityQueue.async { task("🐌")}
//serialPriorityQueue.async { task("🐞")}

// Две очереди с разных приоритетом

//let serialPriorityQueue1 = DispatchQueue(label: "com.surfstudio.serialPriorityQueue1", qos: .userInitiated)
//let serialPriorityQueue2 = DispatchQueue(label: "com.surfstudio.serialPriorityQueue2", qos: .background)
//
//print("---------------------------------")
//print("Private .serial Q1 - .userInitiated")
//print("                Q2 - .background")
//print("---------------------------------")
//
//serialPriorityQueue2.async { task("🐌")}
//serialPriorityQueue1.async { task("🐞")}

// Приватная параллельная очередь (concurrent)

//print("---------------------------------")
//print("Private .concurrent Q1 - .userInitiated")
//print("---------------------------------")
//
//let workerQueue = DispatchQueue(label: "com.surfstudio.concurrentWorker", qos: .userInitiated, attributes: .concurrent)
//
//workerQueue.async { task("🦋") }
//workerQueue.async { task("🐱") }


// Несколько приватных праллельных очередей

//print("---------------------------------")
//print("Private .concurrent Q1 - .userInitiated")
//print("                    Q2 - .background")
//print("---------------------------------")
//
//let concurrentPriorityQueue1 = DispatchQueue(label: "com.surfstudio.concurrentWorker1", qos: .userInitiated, attributes: .concurrent)
//let concurrentPriorityQueue2 = DispatchQueue(label: "com.surfstudio.concurrentWorker2", qos: .background, attributes: .concurrent)
//
//concurrentPriorityQueue2.async { task("🦋")}
//concurrentPriorityQueue1.async { task("🐱")}
