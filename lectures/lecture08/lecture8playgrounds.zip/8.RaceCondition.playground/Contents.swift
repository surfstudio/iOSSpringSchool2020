import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

//Моя serial очередь
let serialQueue = DispatchQueue(label: "com.surfstudio.searialQueue")

print("--- Имитация Race Condition")

var value = "😇"

func changeValue(variant: Int) {
    sleep(1)
    value = value + "🐔"
    print("\(value) - \(variant)")
}

// Заменить на sync для ожидаемого результата
serialQueue.async {
    changeValue(variant: 1)
}
value


value = "🐦"
serialQueue.async {
    changeValue(variant: 2)
}
value
sleep(3)

// 😇🐔 - 1
// 🐦🐔 - 2
