//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let view = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))


image.backgroundColor = UIColor.yellow
image.contentMode = .scaleAspectFit
view.addSubview(image)
PlaygroundPage.current.liveView = view

// Classic way

func fetchImage() {
    let imageURL = URL(string: "https://klike.net/uploads/posts/2019-07/1564314090_3.jpg")!
    let queue = DispatchQueue.global(qos: .utility)
    queue.async {
        if let data = try? Data(contentsOf: imageURL) {
            DispatchQueue.main.async {
                image.image = UIImage(data: data)
                print("Show image data")
            }
            print("Did download  image data")
        }
    }
}

//fetchImage()

/// Work Item

func fetchImage2() {
    var data: Data?
    let queue = DispatchQueue.global(qos: .utility)
    let imageURL = URL(string: "https://klike.net/uploads/posts/2019-07/1564314090_3.jpg")!
    let workItem = DispatchWorkItem { data = try? Data(contentsOf: imageURL) }

    queue.async(execute: workItem)

    workItem.notify(queue: DispatchQueue.main) {
        guard let imageData = data else {
            return
        }
        image.image = UIImage(data: imageData)
    }
}

//fetchImage2()


